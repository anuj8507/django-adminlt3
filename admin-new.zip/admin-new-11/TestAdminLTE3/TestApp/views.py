from django.shortcuts import render
from django.views import generic
from .models import PocrDocs

# Create your views here.


def index(request):
    return render(request, 'TestApp/index.html')

def list(request):
    invoices = PocrDocs.objects.all()
    return render(request, 'TestApp/list.html',{'htmlinvoices': invoices})

def fileupload(request):
    
    return render(request, 'TestApp/fileupload.html')

def logs(request):
    return render(request, 'TestApp/logs.html')

def display_invoice(request, invoice_no):
    # Assuming you have a model called Invoice with a field invoice_number
     invoice_data = PocrDocs.objects.filter(invoice_no=invoice_no)
     return render(request, 'TestApp/display_invoice.html', {'invoice_data': invoice_data})