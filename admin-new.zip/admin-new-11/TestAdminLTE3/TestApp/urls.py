from django.urls import path
from . import views

app_name = 'TestApp'
urlpatterns = [
    path('', views.index, name='index'),
    path('list.html', views.list, name='list'),
    path('fileupload.html', views.fileupload, name='fileupload'),
    path('logs.html', views.logs, name='logs'),
]