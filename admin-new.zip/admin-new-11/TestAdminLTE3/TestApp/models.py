from django.db import models

# Create your models here.
class PocrDocs(models.Model):
    invoice_no = models.CharField(max_length=20)
    provider = models.CharField(max_length=30)
    file_name = models.CharField(max_length=255, blank=True, null=True)
    invoice_data = models.TextField(db_collation='utf8mb4_bin', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pocr_docs'